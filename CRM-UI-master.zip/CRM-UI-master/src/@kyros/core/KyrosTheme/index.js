export { default } from './KyrosTheme';
