export { default } from './KyrosSidePanel';
