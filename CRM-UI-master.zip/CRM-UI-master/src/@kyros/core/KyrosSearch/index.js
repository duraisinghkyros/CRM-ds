export { default } from './KyrosSearch';
