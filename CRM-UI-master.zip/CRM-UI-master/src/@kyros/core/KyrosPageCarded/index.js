export { default } from './KyrosPageCarded';
