export { default } from './KyrosShortcuts';
