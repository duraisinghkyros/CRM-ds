export { default } from './KyrosLoading';
