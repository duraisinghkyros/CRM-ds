export { default } from './KyrosSvgIcon';
