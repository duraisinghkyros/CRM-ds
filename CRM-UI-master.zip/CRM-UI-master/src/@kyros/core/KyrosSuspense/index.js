export { default } from './KyrosSuspense';
