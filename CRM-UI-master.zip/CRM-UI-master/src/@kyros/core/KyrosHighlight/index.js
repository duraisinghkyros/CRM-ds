export { default } from './KyrosHighlight';
