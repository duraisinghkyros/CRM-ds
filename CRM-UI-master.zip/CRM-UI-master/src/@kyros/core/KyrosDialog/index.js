export { default } from './KyrosDialog';
