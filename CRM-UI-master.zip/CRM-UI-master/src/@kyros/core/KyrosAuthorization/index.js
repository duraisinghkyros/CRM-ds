export { default } from './KyrosAuthorization';
