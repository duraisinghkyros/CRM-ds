export { default } from './KyrosSplashScreen';
