export { default } from './KyrosThemeSchemes';
