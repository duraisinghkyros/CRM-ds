export { default } from './KyrosPageSimple';
