import React from 'react'

function UserAvailability() {
  return (
    <div>userAvailability</div>
  )
}

export default UserAvailability