import React from 'react';
import SignaturePage from './SignaturePage'
import MyEmailHeader from './MyEmailHeader';
import KyrosPageCarded from '@kyros/core/KyrosPageCarded/KyrosPageCarded';

function MyEmailSignature() {

  return (
   <>
   <KyrosPageCarded
        // header={<MyEmailHeader />}
        content={
            <SignaturePage />
        }
        />
   
   </>
  )
}

export default MyEmailSignature