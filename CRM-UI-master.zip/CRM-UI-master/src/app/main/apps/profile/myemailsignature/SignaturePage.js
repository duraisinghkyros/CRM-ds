import React from 'react'
import MyEmailSignatureViewPage from './MyEmailSignatureViewPage'

function SignaturePage() {
  return (
    <div><MyEmailSignatureViewPage /></div>
  )
}

export default SignaturePage