import React from "react";
import Button from "@mui/material/Button";
import NavLinkAdapter from "@kyros/core/NavLinkAdapter";
import withReducer from "app/store/withReducer";
import reducer from "../store";
import { useDeepCompareEffect } from "@kyros/hooks";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router-dom";
import { useEffect } from "react";
import KyrosLoading from "@kyros/core/KyrosLoading";
import _ from "@lodash";
import * as yup from "yup";
import { Controller, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup/dist/yup";
import Box from "@mui/system/Box";
import KyrosSvgIcon from "@kyros/core/KyrosSvgIcon";
import Avatar from "@mui/material/Avatar";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import IconButton from "@mui/material/IconButton";
import Autocomplete from "@mui/material/Autocomplete/Autocomplete";
import Checkbox from "@mui/material/Checkbox/Checkbox";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import {
  getMyProfile,
  resetMyProfile,
  //   newProfile,
  selectMyProfile,
  updateMyProfile,
} from "../store/myProfileSlice";
import { selectReportingTo } from "../store/reportingToSlice";
import { selectRole } from "../store/roleSlice";
import { getUserType, selectUserType } from "../store/userTypeSlice";
import {
  getSalesRegions,
  selectSalesRegions,
} from "../store/salesRegionsSlice";
import { getCountry, selectCountry } from "../store/countrySlice";
import { getTeam } from "../store/teamSlice";
import { selectTeam } from "../store/teamSlice";
import { DatePicker } from "@mui/x-date-pickers";
import { getDateFormat, selectDateFormat } from "../store/dateFormatSlice";
import {
  getHolidayCalender,
  selectHolidayCalender,
} from "../store/holidayCalenderSlice";
// import { getWorkDayTemplate, selectWorkDayTemplate } from '../store/workDayTemplateSlice';
import { getWorkDayTemplate } from "../store/workDayTemplate";
import { selectWorkDayTemplate } from "../store/workDayTemplate";
import { useState } from "react";
import { getReportingTo } from "../store/reportingToSlice";
import { getRole } from "../store/roleSlice";
import axios from "axios";
import HelpIcon from "@mui/icons-material/Help";

/**
 * Form Validation Schema
 */
const schema = yup.object().shape({
  name: yup.string().required("You must enter a name"),
});

const ProfileForm = (props) => {
  const myProfile = useSelector(selectMyProfile);
  const routeParams = useParams();
  // const user = useSelector(selectUser);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const reportingTo = useSelector(selectReportingTo);
  const role = useSelector(selectRole);
  const userType = useSelector(selectUserType);
  const salesRegions = useSelector(selectSalesRegions);
  const country = useSelector(selectCountry);
  const dateFormat = useSelector(selectDateFormat);
  const team = useSelector(selectTeam);
  const holidayCalender = useSelector(selectHolidayCalender);
  const workDayTemplate = useSelector(selectWorkDayTemplate);
  const [options, setOptions] = useState([]);
  const [noMyProfile, setNoMyProfile] = useState(false);

  const { control, watch, reset, handleSubmit, formState, getValues } = useForm(
    {
      mode: "onChange",
      resolver: yupResolver(schema),
    }
  );

  const { isValid, dirtyFields, errors } = formState;

  const form = watch();
  function isOptionEqualToValue(option, value) {
    return option === value || (option === "" && value === "");
  }
  const timezones = [
    { label: "(GMT-12:00) International Date Line West" },

    {
      label: "(GMT-11:00) Coordinated Universal Time-11",
    },
    {
      label: "(GMT-10:00) Hawaii",
    },
    {
      label: "(GMT-09:00) Alaska",
    },
    {
      label: "(GMT-08:00) Pacific Time (US & Canada)",
    },
    {
      label: "(GMT-07:00) Arizona",
    },
    {
      label: "(GMT-07:00) Mountain Time (US & Canada)",
    },
    {
      label: "(GMT-06:00) Central Time (US & Canada)",
    },
    {
      label: "(GMT-05:00) Eastern Time (US & Canada)",
    },
    {
      label: "(GMT-04:00) Atlantic Time (Canada)",
    },
    {
      label: "(GMT-03:30) Newfoundland",
    },
    {
      label: "(GMT-03:00) Brasilia",
    },
    {
      label: "(GMT-02:00) Coordinated Universal Time-02",
    },
    {
      label: "(GMT-01:00) Azores",
    },
    {
      label: "(GMT+00:00) London, Dublin, Edinburgh",
    },
    {
      label: "(GMT+01:00) Berlin, Vienna, Rome",
    },
    {
      label: "(GMT+02:00) Athens, Istanbul, Jerusalem",
    },
    {
      label: "(GMT+03:00) Moscow, St. Petersburg, Volgograd",
    },
    {
      label: "(GMT+03:30) Tehran",
    },
    {
      label: "(GMT+04:00) Dubai, Abu Dhabi, Muscat",
    },
    {
      label: "(GMT+04:30) Kabul",
    },
    {
      label: "(GMT+05:00) Islamabad, Karachi, Tashkent",
    },
    {
      label: "(GMT+05:30) Chennai, Kolkata, Mumbai",
    },
    {
      label: "(GMT+05:45) Kathmandu",
    },
    {
      label: "(GMT+06:00) Astana, Dhaka",
    },
    {
      label: "(GMT+06:30) Yangon (Rangoon)",
    },
    {
      label: "(GMT+07:00) Bangkok, Hanoi, Jakarta",
    },
    {
      label: "(GMT+08:00) Beijing, Hong Kong, Kuala Lumpur",
    },
    {
      label: "(GMT+08:45) Eucla",
    },
    {
      label: "(GMT+09:00) Tokyo, Seoul, Osaka",
    },
    {
      label: "(GMT+09:30) Adelaide",
    },
    {
      label: "(GMT+10:00) Canberra, Sydney, Melbourne",
    },
    {
      label: "(GMT+10:00) Brisbane",
    },
    {
      label: "(GMT+10:00) Hobart",
    },
    {
      label: "(GMT+10:00) Vladivostok",
    },
    {
      label: "(GMT+10:00) Guam, Port Moresby",
    },
    {
      label: "(GMT+11:00) Magadan, Solomon Islands, New Caledonia",
    },
    {
      label: "(GMT+12:00) Fiji Islands, Kamchatka, Marshall Islands",
    },
    {
      label: "(GMT+12:00) Auckland, Wellington",
    },
    {
      label: "(GMT+13:00) Nuku'alofa",
    },
  ];

  useDeepCompareEffect(() => {
    function updateUserState() {
      const { userId } = routeParams;
      dispatch(getMyProfile(userId));
    }

    updateUserState();
    dispatch(getReportingTo()); //implement
    dispatch(getRole(getValues()));
    dispatch(getUserType());
    dispatch(getDateFormat());
    dispatch(getTeam(getValues()));
    dispatch(getHolidayCalender());
    dispatch(getWorkDayTemplate());
    dispatch(getCountry());
    dispatch(getSalesRegions());
  }, [dispatch, routeParams]);

  useEffect(() => {
    if (!myProfile) {
      return;
    }
    reset(myProfile);
  }, [myProfile, reset]);

  useEffect(() => {
    return () => {
      dispatch(resetMyProfile());
      setNoMyProfile(false);
    };
  }, [dispatch]);

  function handleSaveUser() {
    const { userId } = routeParams;
    dispatch(updateMyProfile(getValues())).then(() => {
      navigate("/apps/profile/myprofile");
    });
  }

  return (
    <>
      <div className="ml-10 mt-20">
        <h1 className="text-2xl font-bold">
          My Profile <HelpIcon fontSize="small" color="disabled" />
        </h1>
        <h1 className="text-md" style={{ color: "gray" }}>
          Manage Your Personal Profile
        </h1>
        <hr className="border-t-2 border-black-400 " />
      </div>
      <div className="relative flex flex-col flex-auto items-center px-24 sm:px-48 pt-20">
        <Controller
          name="firstName"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              error={!!errors.firstName}
              required
              helperText={errors?.firstName?.message}
              placeholder="First Name"
              label="First Name"
              autoFocus
              id="firstName"
              variant="outlined"
              fullWidth
            />
          )}
        />

        <Controller
          name="lastName"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              error={!!errors.lastName}
              required
              helperText={errors?.lastName?.message}
              label="Last Name"
              id="lastName"
              variant="outlined"
              fullWidth
            />
          )}
        />

        <Controller
          control={control}
          name="emailAddress"
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              label="Email Address"
              required
              placeholder="Email Address"
              variant="outlined"
              fullWidth
              error={!!errors.emailAddress}
              helperText={errors?.emailAddress?.message}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <KyrosSvgIcon size={20}>heroicons-solid:mail</KyrosSvgIcon>
                  </InputAdornment>
                ),
              }}
            />
          )}
        />

        <Controller
          control={control}
          name="phoneMobile"
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              label="Phone(Mobile)"
              placeholder="Phone(Mobile)"
              variant="outlined"
              fullWidth
              required
              error={!!errors.phoneMobile}
              helperText={errors?.phoneMobile?.message}
            />
          )}
        />

        <Controller
          control={control}
          name="roleId"
          defaultValue={0}
          render={({ field: { onChange, value } }) => {
            return (
              <Autocomplete
                id="roleId"
                className="mt-8 mb-24"
                options={role}
                disableCloseOnSelect
                getOptionSelected={(option, value) =>
                  option.value === value.value
                }
                getOptionLabel={(option) =>
                  option ? option.roleName : "No title"
                }
                value={value ? _.find(role, { roleId: value }) : null}
                isOptionEqualToValue={isOptionEqualToValue}
                onChange={(event, newValue) => {
                  onChange(newValue ? newValue.roleId : null);
                }}
                fullWidth
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Role"
                    required
                    placeholder="Role"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                )}
              />
            );
          }}
        />

        <Controller
          control={control}
          defaultValue={0}
          name="userTypeId"
          render={({ field: { onChange, value } }) => {
            return (
              <Autocomplete
                id="userTypeId"
                isOptionEqualToValue={isOptionEqualToValue}
                className="mt-8 mb-24"
                options={userType}
                disableCloseOnSelect
                getOptionSelected={(option, value) =>
                  option.value === value.value
                }
                getOptionLabel={(option) =>
                  option ? option.userTypeName : " "
                }
                value={value ? _.find(userType, { userTypeId: value }) : 0}
                onChange={(event, newValue) => {
                  onChange(newValue ? newValue.userTypeId : 0);
                }}
                fullWidth
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="User Type"
                    required
                    placeholder="User Type"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                )}
              />
            );
          }}
        />

        <Controller
          control={control}
          defaultValue={0}
          name="reportingToId"
          render={({ field: { onChange, value } }) => {
            return (
              <Autocomplete
                id="reportingToId"
                isOptionEqualToValue={isOptionEqualToValue}
                className="mt-8 mb-16"
                options={reportingTo}
                disableCloseOnSelect
                getOptionSelected={(option, value) =>
                  option.value === value.value
                }
                getOptionLabel={(option) => (option ? option.firstName : " ")}
                value={
                  value ? _.find(reportingTo, { reportingToId: value }) : 0
                }
                onChange={(event, newValue) => {
                  onChange(newValue ? newValue.reportingToId : 0);
                }}
                fullWidth
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Reporting To"
                    required
                    placeholder="Reporting To"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                )}
              />
            );
          }}
        />

        <Controller
          control={control}
          defaultValue={""}
          name="dateOfBirth"
          render={({ field }) => (
            <DatePicker
              {...field}
              className="mt-8 mb-16 w-full"
              clearable
              renderInput={(_props) => (
                <TextField
                  {..._props}
                  className="mt-8"
                  id="dateOfBirth"
                  label="Date of Birth"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  variant="outlined"
                  fullWidth
                  error={false}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <KyrosSvgIcon size={20}>
                          heroicons-solid:cake
                        </KyrosSvgIcon>
                      </InputAdornment>
                    ),
                  }}
                />
              )}
            />
          )}
        />

        <Controller
          name="designation"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-24 mb-16"
              error={!!errors.designation}
              helperText={errors?.designation?.message}
              label="Designation"
              // autoFocus
              id="designation"
              variant="outlined"
              fullWidth
            />
          )}
        />

        <Controller
          name="oldTeam"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              error={!!errors.oldTeam}
              helperText={errors?.oldTeam?.message}
              label="Old Team"
              // autoFocus
              id="oldTeam"
              variant="outlined"
              fullWidth
            />
          )}
        />

        <Controller
          name="department"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              error={!!errors.department}
              helperText={errors?.department?.message}
              label="Department"
              // autoFocus
              id="department"
              variant="outlined"
              fullWidth
            />
          )}
        />

        <Controller
          control={control}
          name="salesRegionsId"
          render={({ field: { onChange, value } }) => {
            return (
              <Autocomplete
                id="salesRegionsId"
                isOptionEqualToValue={isOptionEqualToValue}
                className="mt-8 mb-16"
                options={salesRegions}
                disableCloseOnSelect
                getOptionSelected={(option, value) =>
                  option.value === value.value
                }
                getOptionLabel={(option) =>
                  option
                    ? option.districtName + ", " + option.stateName
                    : "No region"
                }
                value={
                  value ? _.find(salesRegions, { salesRegionId: value }) : null
                }
                onChange={(event, newValue) => {
                  onChange(newValue ? newValue.salesRegionId : null);
                }}
                fullWidth
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Sales Region"
                    placeholder="Sales Region"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                )}
              />
            );
          }}
        />

        <Controller
          name="skills"
          control={control}
          defaultValue={[]} // set the default value here
          render={({ field: { onChange, value } }) => (
            <Autocomplete
              className="mt-8 mb-16"
              multiple
              freeSolo
              options={options || []}
              getOptionLabel={(option) => option}
              value={value || []} // set the value prop to the value property of the field object provided by the Controller
              onChange={(event, newValue) => {
                onChange(newValue);
              }}
              fullWidth
              renderInput={(params) => (
                <TextField
                  {...params}
                  placeholder="Select multiple skills"
                  label="Skills"
                  variant="outlined"
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              )}
            />
          )}
        />

        <Controller
          control={control}
          name="countryId"
          render={({ field: { onChange, value } }) => {
            const filteredCountries = salesRegions
              .filter(
                (country) =>
                  country.salesRegionId === getValues().salesRegionsId
              )
              .map((country) => country.country);
            return (
              <Autocomplete
                id="countryId"
                isOptionEqualToValue={isOptionEqualToValue}
                className="mt-8 mb-16"
                options={filteredCountries}
                disableCloseOnSelect
                getOptionSelected={(option, value) =>
                  option.value === value.value
                }
                getOptionLabel={(option) => (option ? option.countryName : " ")}
                value={
                  value ? _.find(filteredCountries, { countryId: value }) : null
                }
                onChange={(event, newValue) => {
                  onChange(newValue ? newValue.countryId : null);
                }}
                fullWidth
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Country"
                    placeholder="Country"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                )}
              />
            );
          }}
        />

        <Controller
          control={control}
          name="phoneMain"
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              label="Phone (Main)"
              placeholder="Phone (Main)"
              variant="outlined"
              fullWidth
              error={!!errors.phoneMain}
              helperText={errors?.phoneMain?.message}
            />
          )}
        />
        <Controller
          control={control}
          name="phoneOthers"
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              label="Phone (Others)"
              placeholder="Phone (Others)"
              variant="outlined"
              fullWidth
              error={!!errors.phoneOthers}
              helperText={errors?.phoneOthers?.message}
            />
          )}
        />
        <Controller
          name="timeZone"
          control={control}
          render={({ field: { onChange, value } }) => (
            <Autocomplete
              className="mt-8 mb-24"
              options={timezones || []}
              error={!!errors.timeZone}
              helperText={errors?.timeZone?.message}
              value={value || ""}
              onChange={(event, newValue) => {
                onChange(newValue.label);
              }}
              fullWidth
              renderInput={(params) => (
                <TextField
                  {...params}
                  placeholder="Time Zone"
                  label="Time Zone"
                  variant="outlined"
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              )}
            />
          )}
        />
        <Controller
          control={control}
          name="dateFormatId"
          render={({ field: { onChange, value } }) => {
            const options = dateFormat.map((option) => ({
              value: option.dateFormatId,
              label: option.dateFormatType || "",
            }));
            return (
              <Autocomplete
                id="dateFormatId"
                isOptionEqualToValue={isOptionEqualToValue}
                className="mt-8 mb-16"
                options={dateFormat}
                disableCloseOnSelect
                getOptionSelected={(option, value) =>
                  option.value === value.value
                }
                getOptionLabel={(option) =>
                  option ? option.dateFormatType : " "
                }
                value={
                  value ? _.find(dateFormat, { dateFormatId: value }) : null
                }
                onChange={(event, newValue) => {
                  onChange(newValue ? newValue.dateFormatId : null);
                }}
                fullWidth
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Date Format"
                    placeholder="Date Format"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                )}
              />
            );
          }}
        />
        <Controller
          control={control}
          defaultValue={0}
          name="teamId"
          render={({ field: { onChange, value } }) => {
            return (
              <Autocomplete
                id="teamId"
                isOptionEqualToValue={isOptionEqualToValue}
                className="mt-5 mb-20"
                options={team}
                disableCloseOnSelect
                getOptionSelected={(option, value) =>
                  option.value === value.value
                }
                getOptionLabel={(option) => (option ? option.teamName : " ")}
                value={value ? _.find(team, { teamId: value }) : 0}
                onChange={(event, newValue) => {
                  onChange(newValue ? newValue.teamId : 0);
                }}
                fullWidth
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Team"
                    placeholder="Team"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                )}
              />
            );
          }}
        />
        <Controller
          control={control}
          defaultValue={0}
          name="holidayId"
          render={({ field: { onChange, value } }) => {
            return (
              <Autocomplete
                id="holidayId"
                isOptionEqualToValue={isOptionEqualToValue}
                className="mt-5 mb-20"
                options={holidayCalender}
                disableCloseOnSelect
                getOptionSelected={(option, value) =>
                  option.value === value.value
                }
                getOptionLabel={(option) =>
                  option ? option.holidayName + " - " + option.holidayDate : " "
                }
                value={
                  value
                    ? _.find(holidayCalender, { holidayCalendarId: value })
                    : 0
                }
                onChange={(event, newValue) => {
                  onChange(newValue ? newValue.holidayCalendarId : 0);
                }}
                fullWidth
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Holiday Calender"
                    placeholder="Holiday Calender"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                )}
              />
            );
          }}
        />
        <Controller
          control={control}
          defaultValue={0}
          name="workDayId"
          render={({ field: { onChange, value } }) => {
            return (
              <Autocomplete
                id="workDayId"
                isOptionEqualToValue={isOptionEqualToValue}
                className="mt-5 mb-20"
                options={workDayTemplate}
                disableCloseOnSelect
                getOptionSelected={(option, value) =>
                  option.value === value.value
                }
                getOptionLabel={(option) =>
                  option
                    ? option.name + " - " + option.workingHours + "(hrs)"
                    : " "
                }
                value={
                  value ? _.find(workDayTemplate, { workDayId: value }) : 0
                }
                onChange={(event, newValue) => {
                  onChange(newValue ? newValue.workDayId : 0);
                }}
                fullWidth
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label="Work Day Template"
                    placeholder="Work Day Template"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                )}
              />
            );
          }}
        />
        <div style={{ marginRight: "400px" }}>
          Is Employee
          <Controller
            name="employee"
            control={control}
            defaultValue={false}
            render={({ field }) => (
              <Checkbox
                {...field}
                color="primary"
                label="Yes"
                inputProps={{ "aria-label": "employee checkbox" }}
              />
            )}
          />
        </div>
        <Controller
          name="employeeId"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              error={!!errors.employeeId}
              helperText={errors?.employeeId?.message}
              label="Employee Id"
              // autoFocus
              id="employeeId"
              variant="outlined"
              fullWidth
              clearable
            />
          )}
        />
        <Controller
          control={control}
          defaultValue={""}
          name="dateOfJoining"
          render={({ field }) => (
            <DatePicker
              {...field}
              className="mt-5 mb-16 w-full"
              clearable
              renderInput={(_props) => (
                <TextField
                  {..._props}
                  className="mt-5"
                  id="dateOfJoining"
                  label="Date of Joining"
                  clearable
                  InputLabelProps={{
                    shrink: true,
                  }}
                  variant="outlined"
                  fullWidth
                  error={false}
                />
              )}
            />
          )}
        />
        <Controller
          control={control}
          defaultValue={""}
          name="dateOfResignation"
          render={({ field }) => (
            <DatePicker
              {...field}
              className="mt-5 mb-16 w-full"
              clearable
              renderInput={(_props) => (
                <TextField
                  {..._props}
                  className="mt-24"
                  id="dateOfResignation"
                  label="Date Of Resignation"
                  InputLabelProps={{
                    shrink: true,
                  }}
                  variant="outlined"
                  fullWidth
                  error={false}
                />
              )}
            />
          )}
        />

        <Controller
          name="locationName"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-16 mb-16"
              label="Location Name"
              id="locationName"
              variant="outlined"
              placeholder="Location Name"
              fullWidth
            />
          )}
        />
        <Controller
          name="address"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              label="Address"
              id="address"
              variant="outlined"
              placeholder="Address"
              fullWidth
            />
          )}
        />
        <Controller
          name="city"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              label="City"
              id="city"
              variant="outlined"
              placeholder="City"
              fullWidth
            />
          )}
        />
        <Controller
          name="state"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              label="State"
              id="state"
              variant="outlined"
              placeholder="State"
              fullWidth
            />
          )}
        />
        <Controller
          name="zipCode"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              className="mt-8 mb-16"
              label="Zipcode"
              // autoFocus
              placeholder="Zipcode"
              id="zipCode"
              variant="outlined"
              error={!!errors.zipCode}
              required
              helperText={errors?.zipCode?.message}
              fullWidth
            />
          )}
        />
      </div>

      <Box
        className="flex items-center mt-40 py-14 pr-16 pl-4 sm:pr-48 sm:pl-36 border-t"
        sx={{ backgroundColor: "background" }}
      >
        <Button
          className="ml-8"
          variant="contained"
          color="secondary"
          onClick={handleSaveUser}
          style={{
            WebkitAppearance: "button",
            backgroundColor: "rgb(55, 48, 163)",
            backgroundImage: "none",
          }}
        >
          Save
        </Button>
      </Box>
    </>
  );
};

export default withReducer("profileApp", reducer)(ProfileForm);
